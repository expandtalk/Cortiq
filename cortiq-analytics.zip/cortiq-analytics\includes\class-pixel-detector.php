<?php
/**
 * Pixel Detector Class
 * Auto-detects tracking pixels on the website and maps them to a cookie library.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class HeatmapAnalyticsPixelDetector {

    private $options;

    /**
     * Cookie library: maps pixel type to the cookies it sets.
     *
     * @var array
     */
    private static $cookie_library = [
        'google_analytics' => [
            [ 'name' => '_ga',   'category' => 'analytics', 'provider' => 'Google Analytics', 'expiry' => '2 år',      'purpose' => 'Unikt besökar-ID för Google Analytics' ],
            [ 'name' => '_gid',  'category' => 'analytics', 'provider' => 'Google Analytics', 'expiry' => '24 timmar', 'purpose' => 'Särskiljer användarsessioner' ],
            [ 'name' => '_ga_*', 'category' => 'analytics', 'provider' => 'Google Analytics', 'expiry' => '2 år',      'purpose' => 'GA4 session-state per property' ],
        ],
        'google_ads' => [
            [ 'name' => '_gcl_au', 'category' => 'marketing', 'provider' => 'Google Ads', 'expiry' => '90 dagar', 'purpose' => 'Mäter annonskonverteringar' ],
        ],
        'facebook' => [
            [ 'name' => '_fbp', 'category' => 'marketing', 'provider' => 'Meta', 'expiry' => '90 dagar', 'purpose' => 'Identifierar webbläsare för Facebook Pixel' ],
            [ 'name' => '_fbc', 'category' => 'marketing', 'provider' => 'Meta', 'expiry' => '90 dagar', 'purpose' => 'Lagrar klickID från Facebook-annonser' ],
        ],
        'linkedin' => [
            [ 'name' => 'lidc',             'category' => 'analytics', 'provider' => 'LinkedIn', 'expiry' => '1 dag',    'purpose' => 'Routing och session-ID' ],
            [ 'name' => 'li_sugr',          'category' => 'marketing', 'provider' => 'LinkedIn', 'expiry' => '90 dagar', 'purpose' => 'Probabilistisk användaridentifiering' ],
            [ 'name' => 'UserMatchHistory', 'category' => 'marketing', 'provider' => 'LinkedIn', 'expiry' => '30 dagar', 'purpose' => 'Synkronisering av LinkedIn-profiler' ],
        ],
        'twitter' => [
            [ 'name' => 'personalization_id', 'category' => 'marketing', 'provider' => 'X (Twitter)', 'expiry' => '2 år', 'purpose' => 'Personalisering av innehåll och annonser' ],
        ],
        'tiktok' => [
            [ 'name' => '_ttp', 'category' => 'marketing', 'provider' => 'TikTok', 'expiry' => '13 månader', 'purpose' => 'Mäter konverteringar från TikTok-annonser' ],
        ],
        'pinterest' => [
            [ 'name' => '_pinterest_ct_ua', 'category' => 'marketing', 'provider' => 'Pinterest', 'expiry' => '1 år', 'purpose' => 'Pinterest konverteringsspårning' ],
        ],
        'snapchat' => [
            [ 'name' => 'sc_at', 'category' => 'marketing', 'provider' => 'Snapchat', 'expiry' => '13 månader', 'purpose' => 'Mäter konverteringar från Snapchat-annonser' ],
        ],
    ];

    public function __construct( $options = [] ) {
        $this->options = $options;

        if ( ! empty( $options['auto_detect_pixels'] ) ) {
            add_action( 'wp_head', [ $this, 'detect_pixels' ], 1 );
        }
    }

    /**
     * Hook into wp_head output buffering to scan the rendered HTML.
     */
    public function detect_pixels() {
        // Use a transient so we only do the expensive scan once every 6 hours.
        if ( get_transient( 'cortiq_pixel_scan_done' ) ) {
            return;
        }
        ob_start( [ $this, 'scan_html_for_pixels' ] );
    }

    /**
     * Scan buffered HTML for pixels, build the cookie library, and save.
     *
     * @param string $html
     * @return string  Unmodified HTML (pass-through).
     */
    public function scan_html_for_pixels( string $html ): string {
        $detected_types = self::run_regex_detection( $html );

        if ( ! empty( $detected_types ) ) {
            $cookies = self::build_cookies_from_types( $detected_types );
            update_option( 'cortiq_auto_cookies', $cookies );

            // Also record detected pixel types and scan timestamp in cortiq_options.
            $current_options = get_option( 'cortiq_options', [] );
            $current_options['detected_pixels']   = $detected_types;
            $current_options['last_pixel_scan']   = current_time( 'mysql' );
            update_option( 'cortiq_options', $current_options );

            cortiq_log( 'Pixel scan: detected ' . implode( ', ', $detected_types ), 'info' );
        }

        set_transient( 'cortiq_pixel_scan_done', 1, 6 * HOUR_IN_SECONDS );

        return $html;
    }

    /**
     * Run all regex detections against $html and return an array of pixel type strings.
     *
     * @param string $html
     * @return string[]
     */
    private static function run_regex_detection( string $html ): array {
        $types = [];

        // Facebook Pixel
        if ( preg_match( '/fbq\([\'"]init[\'"]\s*,\s*[\'"](\d+)[\'"]/', $html ) ) {
            $types[] = 'facebook';
        }

        // Google Ads
        if ( preg_match( '/gtag\([\'"]config[\'"]\s*,\s*[\'"]AW-(\d+)[\'"]/', $html ) ) {
            $types[] = 'google_ads';
        }

        // Google Analytics 4
        if ( preg_match( '/gtag\([\'"]config[\'"]\s*,\s*[\'"]G-([A-Z0-9]+)[\'"]/', $html ) ) {
            $types[] = 'google_analytics';
        }

        // Universal Analytics (UA-) — use the 'google_analytics' library entry as well
        if ( preg_match( '/gtag\([\'"]config[\'"]\s*,\s*[\'"]UA-(\d+-\d+)[\'"]/', $html ) ) {
            if ( ! in_array( 'google_analytics', $types, true ) ) {
                $types[] = 'google_analytics';
            }
        }

        // LinkedIn Insight Tag
        if ( preg_match( '/_linkedin_partner_id\s*=\s*[\'"](\d+)[\'"]/', $html ) ) {
            $types[] = 'linkedin';
        }

        // Twitter / X Pixel
        if ( preg_match( '/twq\([\'"]init[\'"]\s*,\s*[\'"]([a-z0-9]+)[\'"]/', $html ) ) {
            $types[] = 'twitter';
        }

        // Pinterest Tag
        if ( preg_match( '/pintrk\([\'"]load[\'"]\s*,\s*[\'"](\d+)[\'"]/', $html ) ) {
            $types[] = 'pinterest';
        }

        // TikTok Pixel
        if ( preg_match( '/ttq\.load\([\'"]([A-Z0-9]+)[\'"]/', $html ) ) {
            $types[] = 'tiktok';
        }

        // Snapchat Pixel
        if ( preg_match( '/snaptr\([\'"]init[\'"]\s*,\s*[\'"]([a-f0-9-]+)[\'"]/', $html ) ) {
            $types[] = 'snapchat';
        }

        return array_unique( $types );
    }

    /**
     * Build a flat list of cookie entries from detected pixel types.
     *
     * @param string[] $types
     * @return array
     */
    private static function build_cookies_from_types( array $types ): array {
        $cookies = [];
        foreach ( $types as $type ) {
            $entries = self::get_cookies_for_pixel_type( $type );
            foreach ( $entries as $entry ) {
                $entry['source']     = 'auto';
                $entry['pixel_type'] = $type;
                $cookies[]           = $entry;
            }
        }
        return $cookies;
    }

    /**
     * Return the cookie library entries for a given pixel type.
     *
     * @param string $type
     * @return array
     */
    public static function get_cookies_for_pixel_type( string $type ): array {
        return self::$cookie_library[ $type ] ?? [];
    }

    /**
     * Run the full HTML detection and return detected pixel types.
     * Used by the admin AJAX scan (no instance needed).
     *
     * @param string $html
     * @return string[]
     */
    public static function scan_html( string $html ): array {
        return self::run_regex_detection( $html );
    }

    // ── Legacy / instance methods kept for backward compatibility ─────────────

    /**
     * Get all detected pixels (types) from stored options.
     *
     * @return array
     */
    public function get_all_pixels(): array {
        $options  = get_option( 'cortiq_options', [] );
        $detected = $options['detected_pixels'] ?? [];
        return $detected;
    }

    /**
     * Check if a specific pixel type was detected.
     *
     * @param string $type
     * @return bool
     */
    public function has_pixel( string $type ): bool {
        return in_array( $type, $this->get_all_pixels(), true );
    }

    /**
     * Update options reference.
     *
     * @param array $new_options
     */
    public function update_options( $new_options ): void {
        $this->options = $new_options;
    }
}
