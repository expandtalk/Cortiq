<?php
/**
 * Plugin Name: CortIQ Analytics
 * Plugin URI: https://cortiq.se
 * Description: First on the market with Agentic Browser Analytics — track AI agents like ChatGPT Browser, Perplexity Comet and Claude Browser. Includes cookiefree server-side tracking, Core Web Vitals and GDPR compliance. By CortIQ.
 * Version: 5.1.0
 * Author: CortIQ
 * Author URI: https://cortiq.se
 * License: GPL v2 or later
 * Text Domain: cortiq
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ── CortIQ constants ──────────────────────────────────────────────────────────
define( 'CORTIQ_VERSION',     '5.1.0' );
define( 'CORTIQ_PLUGIN_FILE', __FILE__ );
define( 'CORTIQ_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'CORTIQ_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'CORTIQ_CACHE_KEY',   'cortiq_cache_' );
define( 'CORTIQ_CACHE_TIME',  3600 ); // 1 hour

// ── Backward-compat aliases (existing include files still use these) ──────────
if ( ! defined( 'HEATMAP_ANALYTICS_VERSION' ) )    define( 'HEATMAP_ANALYTICS_VERSION',    CORTIQ_VERSION );
if ( ! defined( 'HEATMAP_ANALYTICS_PLUGIN_FILE' ) ) define( 'HEATMAP_ANALYTICS_PLUGIN_FILE', CORTIQ_PLUGIN_FILE );
if ( ! defined( 'HEATMAP_ANALYTICS_PLUGIN_DIR' ) )  define( 'HEATMAP_ANALYTICS_PLUGIN_DIR',  CORTIQ_PLUGIN_DIR );
if ( ! defined( 'HEATMAP_ANALYTICS_PLUGIN_URL' ) )  define( 'HEATMAP_ANALYTICS_PLUGIN_URL',  CORTIQ_PLUGIN_URL );
if ( ! defined( 'HEATMAP_ANALYTICS_CACHE_KEY' ) )   define( 'HEATMAP_ANALYTICS_CACHE_KEY',   CORTIQ_CACHE_KEY );
if ( ! defined( 'HEATMAP_ANALYTICS_CACHE_TIME' ) )  define( 'HEATMAP_ANALYTICS_CACHE_TIME',  CORTIQ_CACHE_TIME );

// ── Logging helper ─────────────────────────────────────────────────────────────
if ( ! function_exists( 'cortiq_log' ) ) {
    function cortiq_log( $message, $level = 'info' ) {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( '[CortIQ ' . $level . '] ' . $message );
        }
    }
}
// Backward compat alias
if ( ! function_exists( 'heatmap_log' ) ) {
    function heatmap_log( $message, $level = 'info' ) {
        cortiq_log( $message, $level );
    }
}

// ── Main plugin class ─────────────────────────────────────────────────────────
class HeatmapAnalyticsCore {

    private $options;
    private $tracking_id;
    public $managers = array();

    public function __construct() {
        $this->init();
        $this->load_dependencies();
        $this->init_hooks();
    }

    private function init() {
        $this->options    = get_option( 'cortiq_options', $this->get_default_options() );
        $this->tracking_id = isset( $this->options['tracking_id'] ) ? $this->options['tracking_id'] : '';
    }

    private function get_default_options() {
        return array(
            'tracking_enabled'             => true,
            'gdpr_enabled'                 => true,
            'cookie_banner_enabled'        => true,
            'data_retention_days'          => 90,
            'anonymize_ip'                 => true,
            'track_mobile'                 => true,
            'performance_mode'             => true,
            'sampling_rate'                => 100,
            'excluded_roles'               => array( 'administrator' ),
            'ip_exclusion_enabled'         => false,
            'excluded_ips'                 => '',
            'form_tracking_enabled'        => true,
            'ga_integration_enabled'       => false,
            'detect_external_consent'      => true,
            'error_logging'                => true,
            'batch_events'                 => true,
            'batch_size'                   => 10,
            'batch_interval'               => 5000,
            'auto_detect_pixels'           => true,
            'plugin_scanner_enabled'       => true,
            'first_party_enabled'          => false,
            'beta_features_enabled'        => false,
            'conversion_tracking_enabled'  => true,
            'ai_insights_enabled'          => false,
            'navigation_sync_enabled'      => true,
            'web_vitals_enabled'           => true,
            'sitekit_integration_enabled'  => false,
            'sitekit_auto_sync'            => true,
            'sitekit_sync_interval'        => 3600,
            'tiktok_integration_enabled'   => false,
            'tiktok_pixel_id'              => '',
            'tiktok_age_verification'      => true,
            'tiktok_china_consent'         => false,
            'supabase_url'                 => 'https://cxmkdtgfocgbfizawlwa.supabase.co',
            'supabase_anon_key'            => 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN4bWtkdGdmb2NnYmZpemF3bHdhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDM3NDkxOTcsImV4cCI6MjA1OTMyNTE5N30.Q6eA_EwEfMV3PWmSdUwu7K4qdzZHgwYgPzcDHg8j7Bw',
            'external_cmp'                 => 'none',
        );
    }

    private function should_load_frontend_features() {
        if ( is_admin() ) return false;
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) return false;
        if ( wp_doing_ajax() ) return false;
        if ( current_user_can( 'manage_options' ) ) return false;
        return true;
    }

    public function load_dependencies() {
        $classes = array(
            'class-cookie-manager.php',
            'class-supabase-sync.php',
            'class-enhanced-cookie-banner-v2.php',
            'class-tracking-manager.php',
            'class-admin-settings.php',
            'class-data-retention.php',
            'class-pixel-detector.php',
            'class-performance-optimizer.php',
            'class-error-handler.php',
            'class-navigation-sync.php',
            'class-google-analytics.php',
            'class-plugin-scanner.php',
            'class-sitekit-integration.php',
            'class-tiktok-integration.php',
            'class-ab-testing-manager.php',
            'class-consent-validator.php',
            'class-web-vitals.php',
            'class-rest-api.php',
        );

        foreach ( $classes as $class_file ) {
            $file_path = CORTIQ_PLUGIN_DIR . 'includes/' . $class_file;
            if ( file_exists( $file_path ) ) {
                require_once $file_path;
            } else {
                cortiq_log( "Missing required file: $class_file", 'error' );
            }
        }

        try {
            $this->managers['cookie']    = new HeatmapAnalyticsCookieManager( $this->options );
            $this->managers['supabase']  = new HeatmapAnalyticsSupabaseSync();

            if ( $this->should_load_frontend_features() ) {
                if ( ! empty( $this->options['cookie_banner_enabled'] ) ) {
                    $this->managers['banner'] = new HeatmapAnalyticsEnhancedCookieBanner( $this->options, $this->tracking_id );
                }
                $this->managers['tracking'] = new HeatmapAnalyticsTrackingManager( $this->options, $this->tracking_id );
                if ( ! empty( $this->options['auto_detect_pixels'] ) ) {
                    $this->managers['pixels'] = new HeatmapAnalyticsPixelDetector( $this->options );
                }
            }

            $this->managers['admin']       = new HeatmapAnalyticsAdminSettings( $this->options, $this->managers['cookie'], null );
            $this->managers['retention']   = new HeatmapAnalyticsDataRetention( $this->options );
            $this->managers['performance'] = new HeatmapAnalyticsPerformanceOptimizer( $this->options );
            $this->managers['errors']      = new HeatmapAnalyticsErrorHandler( $this->options );

            if ( ! empty( $this->options['ga_integration_enabled'] ) ) {
                $this->managers['ga_integration'] = new HeatmapAnalyticsGoogleAnalytics( $this->options );
            }
            if ( ! empty( $this->options['plugin_scanner_enabled'] ) ) {
                $this->managers['plugin_scanner'] = new HeatmapAnalyticsPluginScanner( $this->options );
            }

            $this->managers['navigation'] = new HeatmapAnalyticsNavigationSync( $this->options, $this->managers['supabase'] );
            $this->managers['web_vitals'] = new HeatmapAnalyticsWebVitals( $this->options, $this->tracking_id );

            if ( ! empty( $this->options['sitekit_integration_enabled'] ) ) {
                $supabase_url = isset( $this->options['supabase_url'] ) ? $this->options['supabase_url'] : 'https://cxmkdtgfocgbfizawlwa.supabase.co';
                $this->managers['sitekit'] = new HeatmapAnalyticsSiteKitIntegration( $this->options, $supabase_url, $this->tracking_id );
            }

            $this->managers['rest_api'] = new HeatmapAnalyticsRestAPI( $this->options, $this->managers['sitekit'] ?? null );

            cortiq_log( 'All managers initialized successfully', 'info' );

        } catch ( Exception $e ) {
            cortiq_log( 'Failed to initialize managers: ' . $e->getMessage(), 'error' );
        }
    }

    private function init_hooks() {
        if ( ! empty( $this->options['performance_mode'] ) ) {
            add_action( 'shutdown', array( $this, 'log_performance_metrics' ) );
        }

        if ( ! is_admin() && ! defined( 'REST_REQUEST' ) && ! wp_doing_ajax() ) {
            add_action( 'wp_enqueue_scripts', array( $this, 'add_batch_nonce' ) );
        }

        add_action( 'cortiq_hourly', array( $this, 'hourly_tasks' ) );
    }

    public function add_batch_nonce() {
        if ( ! $this->should_load_frontend_features() ) return;
        wp_localize_script( 'cortiq-tracking', 'cortiq_ajax', array(
            'batch_nonce' => wp_create_nonce( 'cortiq_batch_nonce' ),
        ) );
    }

    public function activate() {
        if ( class_exists( 'Google\Site_Kit\Plugin' ) ) {
            add_option( 'cortiq_sitekit_integration_notice', true );
        }

        $defaults = $this->get_default_options();
        $existing = get_option( 'cortiq_options', array() );
        update_option( 'cortiq_options', wp_parse_args( $existing, $defaults ) );

        $this->create_tables();

        wp_schedule_single_event( time() + 300, 'cortiq_delayed_cron_setup' );
        add_action( 'cortiq_delayed_cron_setup', array( $this, 'setup_cron_jobs' ) );

        cortiq_log( 'Plugin activated successfully', 'info' );
    }

    public function setup_cron_jobs() {
        if ( ! wp_next_scheduled( 'cortiq_hourly' ) ) {
            wp_schedule_event( time(), 'hourly', 'cortiq_hourly' );
        }
        if ( ! wp_next_scheduled( 'cortiq_gdpr_cleanup' ) ) {
            wp_schedule_event( time(), 'daily', 'cortiq_gdpr_cleanup' );
        }
        if ( ! wp_next_scheduled( 'cortiq_daily_cleanup' ) ) {
            wp_schedule_event( time(), 'daily', 'cortiq_daily_cleanup' );
        }
    }

    public function deactivate() {
        wp_clear_scheduled_hook( 'cortiq_gdpr_cleanup' );
        wp_clear_scheduled_hook( 'cortiq_daily_cleanup' );
        wp_clear_scheduled_hook( 'cortiq_hourly' );
        $this->clear_all_cache();
        cortiq_log( 'Plugin deactivated', 'info' );
    }

    private function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $table_name      = $wpdb->prefix . 'cortiq_events';

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            tracking_id varchar(50) NOT NULL,
            session_id varchar(100) NOT NULL,
            event_type varchar(50) NOT NULL,
            event_data longtext,
            user_ip varchar(45),
            user_agent text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            synced tinyint(1) DEFAULT 0,
            PRIMARY KEY (id),
            KEY tracking_id (tracking_id),
            KEY session_id (session_id),
            KEY event_type (event_type),
            KEY created_at (created_at),
            KEY synced (synced)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
        cortiq_log( 'Database tables created/updated', 'info' );
    }

    public function hourly_tasks() {
        if ( isset( $this->managers['supabase'] ) ) {
            $this->managers['supabase']->sync_pending_events();
        }
        cortiq_log( 'Hourly tasks completed', 'info' );
    }

    public function get_options() {
        return $this->options;
    }

    public function update_options( $new_options ) {
        $this->options     = $new_options;
        $this->tracking_id = isset( $new_options['tracking_id'] ) ? $new_options['tracking_id'] : '';

        update_option( 'cortiq_options', $new_options );

        foreach ( $this->managers as $name => $manager ) {
            if ( method_exists( $manager, 'update_options' ) ) {
                try {
                    $ref = new ReflectionMethod( $manager, 'update_options' );
                    if ( $ref->getNumberOfParameters() >= 2 && $name === 'tracking' ) {
                        $manager->update_options( $new_options, $this->tracking_id );
                    } else {
                        $manager->update_options( $new_options );
                    }
                } catch ( Exception $e ) {
                    cortiq_log( 'Error updating manager ' . $name . ': ' . $e->getMessage(), 'error' );
                }
            }
        }

        $this->clear_all_cache();
        cortiq_log( 'Options updated', 'info' );
    }

    private function clear_all_cache() {
        global $wpdb;
        $key = esc_sql( CORTIQ_CACHE_KEY );
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_{$key}%'" );
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_{$key}%'" );
        cortiq_log( 'Cache cleared', 'info' );
    }

    public function log_performance_metrics() {
        if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) return;
        cortiq_log( 'Performance: ' . json_encode( array(
            'memory_peak'    => round( memory_get_peak_usage( true ) / 1024 / 1024, 2 ) . ' MB',
            'execution_time' => round( microtime( true ) - $_SERVER['REQUEST_TIME_FLOAT'], 4 ) . 's',
            'queries'        => get_num_queries(),
        ) ), 'debug' );
    }
}

// ── Activation / deactivation (must be at plugin-load time, not inside 'init') ─
register_activation_hook( __FILE__, function () {
    $core = new HeatmapAnalyticsCore();
    $core->activate();
} );

register_deactivation_hook( __FILE__, function () {
    global $heatmap_core;
    if ( $heatmap_core instanceof HeatmapAnalyticsCore ) {
        $heatmap_core->deactivate();
    } else {
        $core = new HeatmapAnalyticsCore();
        $core->deactivate();
    }
} );

// ── Bootstrap ─────────────────────────────────────────────────────────────────
function cortiq_init() {
    global $heatmap_core;
    $heatmap_core = new HeatmapAnalyticsCore();
}
add_action( 'init', 'cortiq_init' );

// ── Debug footer comment (admin + WP_DEBUG only) ──────────────────────────────
add_action( 'wp_footer', function () {
    if ( ! current_user_can( 'manage_options' ) ) return;
    if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG )  return;
    if ( is_admin() || defined( 'REST_REQUEST' ) )  return;

    $opts = get_option( 'cortiq_options', array() );
    echo '<!-- CortIQ Analytics v' . CORTIQ_VERSION . ' -->';
    echo '<!-- Tracking ID: ' . esc_html( $opts['tracking_id'] ?? 'Not set' ) . ' -->';
    echo '<!-- Web Vitals: ' . ( ! empty( $opts['web_vitals_enabled'] ) ? 'on' : 'off' ) . ' -->';
}, 100 );

// ── Admin notice: missing tracking ID ────────────────────────────────────────
add_action( 'admin_notices', function () {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $opts = get_option( 'cortiq_options', array() );
    if ( ! empty( $opts['tracking_id'] ) ) return;

    $url = admin_url( 'options-general.php?page=cortiq' );
    echo '<div class="notice notice-warning is-dismissible"><p>'
        . '<strong>CortIQ Analytics:</strong> Konfigurera ditt Tracking ID. '
        . '<a href="' . esc_url( $url ) . '">Gå till inställningar</a></p></div>';
} );

// ── AJAX: get site ID ─────────────────────────────────────────────────────────
add_action( 'wp_ajax_nopriv_cortiq_get_site_id', function () {
    global $heatmap_core;
    if ( isset( $heatmap_core->managers['tracking'] ) ) {
        wp_send_json_success( array( 'site_id' => $heatmap_core->managers['tracking']->get_site_id() ) );
    }
    wp_send_json_error( 'Tracking manager not available' );
} );
add_action( 'wp_ajax_cortiq_get_site_id', function () {
    global $heatmap_core;
    if ( isset( $heatmap_core->managers['tracking'] ) ) {
        wp_send_json_success( array( 'site_id' => $heatmap_core->managers['tracking']->get_site_id() ) );
    }
    wp_send_json_error( 'Tracking manager not available' );
} );

// ── AJAX: plugin status ───────────────────────────────────────────────────────
add_action( 'wp_ajax_cortiq_check_status', function () {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Insufficient permissions' );
    }
    global $heatmap_core;
    $opts   = $heatmap_core->get_options();
    $status = array(
        'version'           => CORTIQ_VERSION,
        'tracking_enabled'  => ! empty( $opts['tracking_enabled'] ),
        'tracking_id_set'   => ! empty( $opts['tracking_id'] ),
        'gdpr_enabled'      => ! empty( $opts['gdpr_enabled'] ),
        'web_vitals_enabled' => ! empty( $opts['web_vitals_enabled'] ),
        'managers_loaded'   => array(),
    );
    foreach ( array( 'cookie', 'supabase', 'banner', 'tracking', 'admin', 'web_vitals' ) as $m ) {
        $status['managers_loaded'][ $m ] = isset( $heatmap_core->managers[ $m ] );
    }
    wp_send_json_success( $status );
} );

// ── Uninstall ─────────────────────────────────────────────────────────────────
register_uninstall_hook( __FILE__, 'cortiq_uninstall' );

function cortiq_uninstall() {
    delete_option( 'cortiq_options' );
    delete_option( 'cortiq_manual_cookies' );
    delete_option( 'cortiq_errors' );
    delete_option( 'cortiq_site_id' );

    global $wpdb;
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}cortiq_events" );
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_cortiq_%'" );
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_cortiq_%'" );

    wp_clear_scheduled_hook( 'cortiq_gdpr_cleanup' );
    wp_clear_scheduled_hook( 'cortiq_daily_cleanup' );
    wp_clear_scheduled_hook( 'cortiq_hourly' );
}

// ── GDPR consent handler ──────────────────────────────────────────────────────
require_once CORTIQ_PLUGIN_DIR . 'includes/class-gdpr-consent-handler.php';
