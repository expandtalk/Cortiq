<?php
/**
 * Web Vitals Tracker
 *
 * Measures and reports Core Web Vitals (LCP, INP, CLS, FCP, TTFB) to CortIQ.
 * No personal data collected — purely technical performance measurements.
 * GDPR: no consent required (Article 6(1)(f) legitimate interest / technical telemetry).
 *
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class HeatmapAnalyticsWebVitals {

	private $options;
	private $tracking_id;
	private $supabase_url;
	private $supabase_anon_key;

	public function __construct( $options, $tracking_id ) {
		$this->options          = $options;
		$this->tracking_id      = $tracking_id;
		$this->supabase_url     = isset( $options['supabase_url'] ) ? $options['supabase_url'] : 'https://cxmkdtgfocgbfizawlwa.supabase.co';
		$this->supabase_anon_key = isset( $options['supabase_anon_key'] ) ? $options['supabase_anon_key'] : '';

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
	}

	public function enqueue_scripts() {
		if ( empty( $this->tracking_id ) ) {
			return;
		}

		if ( empty( $this->options['web_vitals_enabled'] ) ) {
			return;
		}

		// Official Google web-vitals library (IIFE build, loaded in footer, deferred)
		wp_enqueue_script(
			'cortiq-web-vitals-lib',
			'https://unpkg.com/web-vitals@4/dist/web-vitals.iife.js',
			array(),
			'4.2.4',
			array( 'strategy' => 'defer', 'in_footer' => true )
		);

		wp_add_inline_script( 'cortiq-web-vitals-lib', $this->get_reporter_script(), 'after' );
	}

	private function get_reporter_script() {
		// Dedicated track-web-vitals endpoint — separate from track-event which uses company API keys
		$endpoint    = esc_js( trailingslashit( $this->supabase_url ) . 'functions/v1/track-web-vitals' );
		$anon_key    = esc_js( $this->supabase_anon_key );
		$tracking_id = esc_js( $this->tracking_id );

		return <<<JS
(function () {
    'use strict';

    var endpoint    = '{$endpoint}';
    var trackingId  = '{$tracking_id}';
    var anonKey     = '{$anon_key}';

    if (typeof webVitals === 'undefined') { return; }

    // One UUID per page load — used to upsert all metrics into a single web_vitals row
    var pageSession = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0;
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });

    function deviceType() {
        var w = window.innerWidth;
        return w < 768 ? 'mobile' : w < 1024 ? 'tablet' : 'desktop';
    }

    function connectionType() {
        return (navigator.connection && navigator.connection.effectiveType) || 'unknown';
    }

    function send(metric) {
        // CLS stored as integer (value * 1000) to avoid float precision issues in DB
        var value = metric.name === 'CLS'
            ? Math.round(metric.value * 1000)
            : Math.round(metric.value);

        var payload = JSON.stringify({
            tracking_id:     trackingId,
            session_id:      pageSession,
            metric_name:     metric.name,
            metric_value:    value,
            metric_rating:   metric.rating,
            page_url:        window.location.pathname,
            device_type:     deviceType(),
            connection_type: connectionType(),
            timestamp:       new Date().toISOString()
        });

        try {
            fetch(endpoint, {
                method:    'POST',
                headers:   {
                    'Content-Type': 'application/json',
                    'apikey':       anonKey,
                    'Authorization': 'Bearer ' + anonKey
                },
                body:      payload,
                keepalive: true
            });
        } catch (e) { /* non-blocking — vitals are best-effort telemetry */ }
    }

    // Report each vital once per page load (reportAllChanges: false)
    webVitals.onLCP(send,  { reportAllChanges: false });
    webVitals.onINP(send,  { reportAllChanges: false });
    webVitals.onCLS(send,  { reportAllChanges: false });
    webVitals.onFCP(send);
    webVitals.onTTFB(send);
})();
JS;
	}
}
