<?php
/**
 * CortIQ Cookie Consent Banner
 * GDPR-compliant: equal button prominence, no pre-ticked optional cookies,
 * granular choices, easy withdrawal.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class HeatmapAnalyticsEnhancedCookieBanner {

    private $options;
    private $tracking_id;

    const COOKIE_NAME = 'cortiq_consent';

    public function __construct( $options, $tracking_id = '' ) {
        $this->options     = $options;
        $this->tracking_id = $tracking_id ?: ( isset( $options['tracking_id'] ) ? $options['tracking_id'] : '' );

        if ( empty( $this->options['cookie_banner_enabled'] ) ) {
            return;
        }

        add_action( 'wp_footer', [ $this, 'render' ], 100 );
        add_action( 'wp_ajax_nopriv_cortiq_store_consent', [ $this, 'ajax_store_consent' ] );
        add_action( 'wp_ajax_cortiq_store_consent',        [ $this, 'ajax_store_consent' ] );
    }

    private function has_consent(): bool {
        // If any external CMP is configured, always suppress our banner
        if ( ( $this->options['external_cmp'] ?? 'none' ) !== 'none' ) {
            return true;
        }
        return isset( $_COOKIE[ self::COOKIE_NAME ] );
    }

    public function render(): void {
        if ( $this->has_consent() ) {
            return;
        }

        $nonce    = wp_create_nonce( 'cortiq_consent_nonce' );
        $ajax_url = esc_js( admin_url( 'admin-ajax.php' ) );
        $site_id  = esc_js( $this->tracking_id );
        ?>
        <div id="cortiq-banner" role="dialog" aria-label="Cookie-inställningar">
            <div class="cortiq-banner-inner">
                <div class="cortiq-banner-text">
                    <strong>Den här webbplatsen använder cookies</strong>
                    <p>Vi använder cookies för att analysera trafik och förbättra upplevelsen. Du väljer själv vad du tillåter och kan ändra dig när som helst.</p>
                </div>
                <div class="cortiq-banner-btns">
                    <button id="cortiq-reject"   class="cortiq-btn cortiq-btn-ghost">Neka alla</button>
                    <button id="cortiq-settings"  class="cortiq-btn cortiq-btn-ghost">Anpassa</button>
                    <button id="cortiq-accept"    class="cortiq-btn cortiq-btn-solid">Acceptera alla</button>
                </div>
            </div>
        </div>

        <div id="cortiq-modal" role="dialog" aria-modal="true" aria-label="Cookie-inställningar" hidden>
            <div class="cortiq-modal-box">
                <h2>Cookie-inställningar</h2>
                <p>Välj vilka cookies du vill tillåta. Du kan ändra dina val närsomhelst.</p>

                <div class="cortiq-cat">
                    <div class="cortiq-cat-row">
                        <div class="cortiq-cat-label">
                            <strong>Nödvändiga</strong>
                            <span>Krävs för webbplatsens grundfunktioner. Kan inte stängas av.</span>
                        </div>
                        <span class="cortiq-always-on">Alltid aktiv</span>
                    </div>
                </div>

                <div class="cortiq-cat">
                    <div class="cortiq-cat-row">
                        <div class="cortiq-cat-label">
                            <strong>Analys</strong>
                            <span>Anonymiserad statistik om hur webbplatsen används.</span>
                        </div>
                        <label class="cortiq-toggle" aria-label="Tillåt analys-cookies">
                            <input type="checkbox" id="cq-analytics">
                            <span class="cortiq-track"></span>
                        </label>
                    </div>
                </div>

                <div class="cortiq-cat">
                    <div class="cortiq-cat-row">
                        <div class="cortiq-cat-label">
                            <strong>Marknadsföring</strong>
                            <span>Används för anpassad annonsering av tredje part.</span>
                        </div>
                        <label class="cortiq-toggle" aria-label="Tillåt marknadsförings-cookies">
                            <input type="checkbox" id="cq-marketing">
                            <span class="cortiq-track"></span>
                        </label>
                    </div>
                </div>

                <div class="cortiq-modal-btns">
                    <button id="cq-reject-modal"  class="cortiq-btn cortiq-btn-ghost">Neka alla</button>
                    <button id="cq-accept-modal"  class="cortiq-btn cortiq-btn-ghost">Acceptera alla</button>
                    <button id="cq-save"          class="cortiq-btn cortiq-btn-solid">Spara val</button>
                </div>
            </div>
        </div>

        <style>
        #cortiq-banner {
            position: fixed; bottom: 0; left: 0; right: 0;
            background: #fff;
            border-top: 2px solid #111827;
            box-shadow: 0 -4px 24px rgba(0,0,0,.10);
            z-index: 99998;
            padding: 16px 20px;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            font-size: 14px;
            line-height: 1.5;
        }
        .cortiq-banner-inner {
            max-width: 1100px; margin: 0 auto;
            display: flex; align-items: center; gap: 24px; flex-wrap: wrap;
        }
        .cortiq-banner-text { flex: 1; min-width: 220px; }
        .cortiq-banner-text strong { display: block; margin-bottom: 3px; color: #111827; font-size: 15px; }
        .cortiq-banner-text p { margin: 0; color: #4b5563; }
        .cortiq-banner-btns { display: flex; gap: 10px; flex-shrink: 0; flex-wrap: wrap; }

        .cortiq-btn {
            padding: 10px 20px; border-radius: 6px; font-size: 14px;
            font-weight: 600; cursor: pointer; transition: background .15s, color .15s;
            white-space: nowrap; border: 2px solid #111827;
        }
        .cortiq-btn-solid  { background: #111827; color: #fff; }
        .cortiq-btn-solid:hover  { background: #1f2937; }
        .cortiq-btn-ghost  { background: #fff; color: #111827; }
        .cortiq-btn-ghost:hover  { background: #f9fafb; }

        #cortiq-modal {
            position: fixed; inset: 0;
            background: rgba(0,0,0,.55);
            z-index: 99999;
            display: flex; align-items: center; justify-content: center;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        #cortiq-modal[hidden] { display: none; }
        .cortiq-modal-box {
            background: #fff; border-radius: 12px; padding: 32px;
            max-width: 480px; width: 90%; max-height: 85vh; overflow-y: auto;
        }
        .cortiq-modal-box h2 { margin: 0 0 8px; font-size: 20px; color: #111827; }
        .cortiq-modal-box > p { margin: 0 0 24px; color: #4b5563; font-size: 14px; }
        .cortiq-cat {
            border: 1px solid #e5e7eb; border-radius: 8px;
            padding: 14px 16px; margin-bottom: 10px;
        }
        .cortiq-cat-row {
            display: flex; justify-content: space-between;
            align-items: center; gap: 16px;
        }
        .cortiq-cat-label strong { display: block; color: #111827; font-size: 14px; margin-bottom: 2px; }
        .cortiq-cat-label span   { color: #6b7280; font-size: 13px; }
        .cortiq-always-on { font-size: 12px; color: #16a34a; font-weight: 600; white-space: nowrap; }

        .cortiq-toggle { position: relative; display: inline-block; width: 44px; height: 24px; flex-shrink: 0; cursor: pointer; }
        .cortiq-toggle input { opacity: 0; width: 0; height: 0; position: absolute; }
        .cortiq-track {
            position: absolute; inset: 0;
            background: #d1d5db; border-radius: 24px; transition: background .2s;
        }
        .cortiq-track::before {
            content: ""; position: absolute;
            width: 18px; height: 18px; top: 3px; left: 3px;
            background: #fff; border-radius: 50%; transition: transform .2s;
        }
        .cortiq-toggle input:checked + .cortiq-track { background: #111827; }
        .cortiq-toggle input:checked + .cortiq-track::before { transform: translateX(20px); }
        .cortiq-toggle input:focus-visible + .cortiq-track { outline: 2px solid #111827; outline-offset: 2px; }

        .cortiq-modal-btns { display: flex; gap: 10px; margin-top: 24px; flex-wrap: wrap; justify-content: flex-end; }

        @media (max-width: 600px) {
            .cortiq-banner-inner  { flex-direction: column; align-items: stretch; }
            .cortiq-banner-btns   { flex-direction: column; }
            .cortiq-btn           { text-align: center; }
            .cortiq-modal-box     { padding: 20px; }
            .cortiq-modal-btns    { flex-direction: column-reverse; }
        }
        </style>

        <script>
        (function () {
            var COOKIE  = '<?php echo self::COOKIE_NAME; ?>';
            var AJAX    = '<?php echo $ajax_url; ?>';
            var NONCE   = '<?php echo esc_js( $nonce ); ?>';
            var SITE_ID = '<?php echo $site_id; ?>';

            var banner = document.getElementById('cortiq-banner');
            var modal  = document.getElementById('cortiq-modal');

            function setCookie(val) {
                var d = new Date();
                d.setFullYear(d.getFullYear() + 1);
                document.cookie = COOKIE + '=' + encodeURIComponent(JSON.stringify(val))
                    + '; expires=' + d.toUTCString()
                    + '; path=/; SameSite=Lax';
            }

            function save(choices) {
                setCookie(choices);
                banner.style.display = 'none';
                modal.hidden = true;
                window.dispatchEvent(new CustomEvent('cortiqConsent', { detail: choices }));
                // Fire-and-forget to server
                var fd = new FormData();
                fd.append('action', 'cortiq_store_consent');
                fd.append('nonce', NONCE);
                fd.append('site_id', SITE_ID);
                fd.append('consent', JSON.stringify(choices));
                fetch(AJAX, { method: 'POST', body: fd }).catch(function () {});
            }

            var ALL  = { necessary: true, analytics: true, marketing: true };
            var NONE = { necessary: true, analytics: false, marketing: false };

            document.getElementById('cortiq-accept').addEventListener('click', function () { save(ALL); });
            document.getElementById('cortiq-reject').addEventListener('click', function () { save(NONE); });
            document.getElementById('cortiq-settings').addEventListener('click', function () { modal.hidden = false; });

            document.getElementById('cq-accept-modal').addEventListener('click', function () { save(ALL); });
            document.getElementById('cq-reject-modal').addEventListener('click', function () { save(NONE); });
            document.getElementById('cq-save').addEventListener('click', function () {
                save({
                    necessary: true,
                    analytics: document.getElementById('cq-analytics').checked,
                    marketing: document.getElementById('cq-marketing').checked
                });
            });

            // Close modal on backdrop click
            modal.addEventListener('click', function (e) {
                if (e.target === modal) { modal.hidden = true; }
            });
            // Close modal on Escape
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && !modal.hidden) { modal.hidden = true; }
            });
        })();
        </script>
        <?php
    }

    public function ajax_store_consent(): void {
        check_ajax_referer( 'cortiq_consent_nonce', 'nonce' );

        $site_id = sanitize_text_field( $_POST['site_id'] ?? '' );
        $consent = json_decode( stripslashes( $_POST['consent'] ?? '' ), true );

        if ( ! is_array( $consent ) ) {
            wp_send_json_error( 'invalid_payload' );
        }

        $opts     = get_option( 'cortiq_options', [] );
        $supa_url = $opts['supabase_url']      ?? 'https://cxmkdtgfocgbfizawlwa.supabase.co';
        $supa_key = $opts['supabase_anon_key'] ?? '';

        if ( $supa_url && $supa_key ) {
            wp_remote_post( $supa_url . '/functions/v1/store-consent', [
                'headers' => [
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $supa_key,
                    'apikey'        => $supa_key,
                ],
                'body'    => wp_json_encode( [
                    'site_id'       => $site_id,
                    'consent_types' => $consent,
                    'source'        => 'wordpress_banner',
                    'user_agent'    => isset( $_SERVER['HTTP_USER_AGENT'] )
                        ? sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] )
                        : '',
                ] ),
                'timeout'  => 5,
                'blocking' => false,
            ] );
        }

        wp_send_json_success();
    }

    public function update_options( $new_options ): void {
        $this->options = $new_options;
    }
}
