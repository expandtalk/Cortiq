=== CortIQ Analytics ===
Contributors: cortiq
Tags: agentic-analytics, ai-tracking, heatmap, cookiefree, serverside-analytics, gdpr, chatgpt-browser, perplexity
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 5.1.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

First on the market with Agentic Browser Analytics + Cookiefree Serverside Tracking. Track AI agents and eliminate cookie banners.

== Description ==

**CortIQ Analytics** is the first on the market with dedicated **Agentic Browser Analytics** - track when AI agents like ChatGPT Browser, Perplexity Comet, and Claude Browser visit your website. Combined with **cookiefree serverside tracking**, you get 100% GDPR-compliant analytics without any cookie banners.

### 🤖 Agentic Browser Analytics (World First!)

* **Track AI Agents** - ChatGPT Browser, Perplexity Comet, Claude Browser and more
* **Agent-specific dashboards** - See how AI agents interact with your website
* **Structured data analysis** - Understand how well your site is prepared for the agentic web
* **Agent conversion attribution** - Measure conversions from AI-driven traffic
* **Future-proof** - Ready for when 10-15% of all traffic comes from bots within three years

### 🍪 Cookiefree Serverside Analytics

* **No cookie banners** - Eliminate cookie disruptions completely
* **100% GDPR-compliant** - Serverside tracking without personal data in browser
* **Better conversion** - No annoying banners reducing conversion rates
* **Complete data** - All the analytics you need without cookies
* **GA4 Server-Side** - Want to keep Google Analytics? We run it serverside

### 🔥 Traditional Analytics (Also Included)

* **Heatmap visualization** - Click, scroll and attention maps
* **Google Analytics 4 integration** - Combine with GA4 data
* **A/B Testing** - Built-in testing platform
* **Form Analytics** - Detailed form analysis
* **Real-time data** - Live tracking with batch optimization

### 🚀 Why Choose Us?

* **Unique features** - No one else has agentic browser tracking + cookiefree analytics
* **Competitive advantage** - Stay ahead of your competitors in the new agentic web
* **Expert support** - Personal help when you need it
* **GDPR expert** - We understand European data protection requirements perfectly

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/heatmap-analytics` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings → Heatmap Analytics for configuration
4. Enter your Tracking ID from the CortIQ dashboard (cortiq.se)
5. Choose between cookiefree serverside or traditional tracking
6. Enable Agentic Browser Analytics to track AI agents
7. Configure Google Analytics integration (optional)

== Changelog ==

= 5.1.0 =
* NEW: Core Web Vitals tracking — LCP, INP, CLS, FCP, TTFB
* No consent required — pure performance telemetry, no personal data
* Web Vitals data synced to CortIQ dashboard with per-page, per-device breakdown
* Google's ranking factors (LCP, INP, CLS) directly visible in analytics
* New Web Vitals tab in plugin settings

= 5.0.0 =
* NEW: Agentic Browser Analytics - first on the market!
* NEW: Track ChatGPT Browser, Perplexity Comet and Claude Browser
* NEW: Cookiefree Serverside Analytics - eliminate cookie banners completely
* NEW: GA4 Server-Side Integration capability
* Agent-specific dashboards and insights
* Structured data readiness scoring
* Agent conversion attribution
* Improved user experience without cookie banners
* 100% GDPR-compliant without cookies

= 4.2.0 =
* Google Site Kit integration
* TikTok Pixel integration
* Navigation sync improvements

= 3.0.0 =
* Proper Supabase integration
* Improved tracking with retry logic
* Advanced IP exclusion with CIDR support
* Sampling functionality
* Mobile tracking control
